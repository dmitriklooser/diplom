package pojo;

public class TypeRoom {
    private int id;
    private String type;
    
    public void setType(String type){
        this.type = type;
   }
    
    public String getType(){
       return type;
   }
    
    public void setId(int id){
        this.id = id;
   }
    
    public int getId(){
       return id;
   }
   
}
