package pojo;

public class Grp {
    private int id;
    private int groupSize;
    
    public void setId(int id){
        this.id = id;
   }
    
    public int getId(){
       return id;
   }
    
    public void setGroupSize(int groupSize){
        this.groupSize = groupSize;
   }
    
    public int getGroupSize(){
       return groupSize;
   }
   
   
}
