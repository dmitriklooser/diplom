package pojo;

public class GrpMod {
    private Module mod;
    private Grp gro;
    
    public void setModule(Module mod){
        this.mod = mod;
   }
    
    public Module getModule(){
       return mod;
   }
    
    public void setGrp(Grp gro){
        this.gro = gro;
   }
    
    public Grp getGrp(){
       return gro;
   }
   
}
