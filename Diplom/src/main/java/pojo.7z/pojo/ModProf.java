package pojo;

public class ModProf {
    private Module mod;
    private Professor pro;
    
    public void setModule(Module mod){
        this.mod = mod;
   }
    
    public Module getModule(){
       return mod;
   }
    
    public void setProfessor(Professor pro){
        this.pro = pro;
   }
    
    public Professor getProfessor(){
       return pro;
   }
}
